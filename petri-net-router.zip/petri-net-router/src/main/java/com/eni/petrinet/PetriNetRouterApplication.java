package com.eni.petrinet;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PetriNetRouterApplication {

	public static void main(String[] args) {
		SpringApplication.run(PetriNetRouterApplication.class, args);
	}

}
